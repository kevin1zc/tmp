import matplotlib.pyplot as plt
import pandas as pd
import os

randpol_dir = "data/randpol_1.csv"
sb3_dir = "data/ppo_sb3_1.csv"
# rllib_dir = "rllib_2.csv"

data_randpol = pd.read_csv(randpol_dir).to_numpy()
data_sb3 = pd.read_csv(sb3_dir).to_numpy()
# data_rllib = pd.read_csv(rllib_dir).to_numpy()

data_randpol[:, 0] -= data_randpol[0, 0]
data_sb3[:, 0] -= data_sb3[0, 0]
# data_rllib[:, 0] -= data_rllib[0, 0]

plt.xlabel("Wall Time (s)")
plt.ylabel("Reward")
plt.plot(data_randpol[:, 0], data_randpol[:, -1], label="RANDPOL")
plt.plot(data_sb3[:, 0], data_sb3[:, -1], label="PPO_SB3")
# plt.plot(data_rllib[:, 0], data_rllib[:, -1], label="PPO_RLlib")
plt.legend()

# plt.show()
plt.savefig("data/Compare_1.png")
