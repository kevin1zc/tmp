"""
Train RANDPOL Agent
"""

import os
import numpy as np
from datetime import datetime
import argparse

from torch import nn

from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3.common.noise import OrnsteinUhlenbeckActionNoise
from stable_baselines3.common.vec_env import SubprocVecEnv, VecNormalize
from stable_baselines3.common.callbacks import CallbackList, EvalCallback

from utils.sb3_randpol_algorithm import RANDPOL
from utils.sb3_randpol_policy import RANDPOLPolicy
from utils_on_policy.randpol_algorithm_2 import RANDPOL2
from utils.sb3_callbacks import SaveVecNormalizeCallback, CheckpointVecNormCallback, UpdateBatchSizeCallback

# from envs.running_task_cartesian import QuadrupedGymEnv
# from envs.running_task_joint import QuadrupedGymEnv

from envs.running_task_cartesian_go1 import QuadrupedGymEnv
# from envs.running_task_joint_go1 import QuadrupedGymEnv

# from sb3_contrib.common.recurrent.policies import RecurrentActorCriticPolicy
# from sb3_contrib.ppo_recurrent.ppo_recurrent import RecurrentPPO

# from usc_learning.envs.quadruped_master.quadruped_gym_env import QuadrupedGymEnv

def main(parser):
    args = parser.parse_args()

    monitor_dir = '{}_{}'.format(datetime.now().strftime("%Y-%m-%d_%H-%M-%S"), args.env)

    # Training
    os.makedirs("logs", exist_ok=True)
    os.makedirs("logs/" + monitor_dir, exist_ok=True)

    model_name = args.name
    if args.rand:
        model_name += "_RAND_"
    # decay_rate = args.decay_rate
    lr_actor = args.lr_actor
    lr_critic = args.lr_critic
    gamma = args.gamma
    replay_size = args.buffer_size
    batch_size = args.batch_size
    steps_to_start_learn = args.steps_to_start_learn
    test_iter = args.test_iter
    max_steps = args.max_steps
    training_random_seed = args.seed
    env_name = args.env

    n_envs = 16
    n_eval_envs = 8

    env_kwargs = {}
    if env_name == "QuadrupedGymEnv-v0":
        env_name = QuadrupedGymEnv
        # End-to-end
        # env_kwargs = dict(time_step=0.001, action_repeat=10, obs_hist_len=5)
        env_kwargs = dict(time_step=0.001, action_repeat=10, obs_hist_len=10, obs_hist_space=5)

        # env_kwargs = dict(task_env="FWD_LOCOMOTION",
        #                            observation_space_mode="DEFAULT_CONTACTS",
        #                            energy_weight=0.008,
        #                            distance_weight=5.0,
        #                            time_remaining_in_obs_space=False,
        #                            gait_signal_in_obs_space=False,
        #                            add_terrain_noise=True,
        #                            observation_history_length=5,
        #                            randomize_dynamics=True,
        #                            observation_noise_stdev=0.05)


    elif env_name == "LunarLander-v2":
        env_kwargs = dict(continuous=True)

    env = make_vec_env(env_name, n_envs, vec_env_cls=SubprocVecEnv, env_kwargs=env_kwargs,
                       vec_env_kwargs=dict(start_method="spawn"))
    env = VecNormalize(env)
    eval_env = make_vec_env(env_name, n_eval_envs, vec_env_cls=SubprocVecEnv, env_kwargs=env_kwargs,
                            vec_env_kwargs=dict(start_method="spawn"))
    eval_env = VecNormalize(eval_env)

    log_dir = os.path.join("logs/" + monitor_dir)
    ckpt_save_path = os.path.join(log_dir, "saved_checkpoints")
    best_model_save_path = os.path.join(log_dir, "best_model")
    log_path = os.path.join(log_dir, "results")
    tensorboard_path = os.path.join(log_dir, "tensorboard_log")
    final_save_path = os.path.join(log_dir, "final_save")

    # policy_kwargs = dict(
    #     lr_actor=lr_actor,
    #     lr_critic=lr_critic,
    #     net_arch=dict(pi=[800, 800], qf=[800, 800]),
    #     n_critics=2,
    #     activation_fn=nn.ReLU,
    #     # activation_fn=nn.Tanh,
    #     # activation_fn=nn.LeakyReLU,
    # )

    n_actions = env.action_space.shape[-1]
    action_noise = OrnsteinUhlenbeckActionNoise(mean=np.zeros(n_actions), sigma=0.2 * np.ones(n_actions), theta=0.15,
                                                dt=1.0)

    # model = RANDPOL(policy=RANDPOLPolicy, env=env, learning_rate=lr_actor, buffer_size=replay_size, gradient_steps=-1,
    #                 learning_starts=steps_to_start_learn, batch_size=batch_size, tau=0.005, gamma=gamma,
    #                 action_noise=action_noise, policy_kwargs=policy_kwargs, verbose=0, policy_delay=1,
    #                 tensorboard_log=tensorboard_path, train_freq=(50, "step"))
    model = RANDPOL2("MlpPolicy", env, verbose=0, tensorboard_log=tensorboard_path, learning_rate=lr_actor, n_steps=200,
                     gamma=gamma, policy_kwargs=dict(net_arch=dict(pi=[500, 800], vf=[500, 800])), vf_coef=1.0)

    # Off-policy algorithms
    # from stable_baselines3.ddpg import DDPG
    # from stable_baselines3.sac import SAC
    # from stable_baselines3.td3 import TD3

    # On-policy algorithms
    # from stable_baselines3.a2c import A2C
    # from stable_baselines3.ppo import PPO
    # model = DDPG("MlpPolicy", env, action_noise=action_noise, verbose=0, tensorboard_log=tensorboard_path,
    #              learning_rate=lr_actor, batch_size=batch_size, gamma=gamma, train_freq=(50, "step"),
    #              policy_kwargs=dict(net_arch=dict(pi=[400, 400], qf=[400, 400])))
    # model = TD3("MlpPolicy", env, action_noise=action_noise, verbose=0, tensorboard_log=tensorboard_path,
    #             learning_rate=lr_actor, batch_size=batch_size, gamma=gamma, train_freq=(50, "step"),
    #             policy_kwargs=dict(net_arch=dict(pi=[400, 400], qf=[400, 400])))
    # model = PPO("MlpPolicy", env, verbose=0, tensorboard_log=tensorboard_path, learning_rate=lr_actor, n_steps=200,
    #             batch_size=batch_size, gamma=gamma, policy_kwargs=dict(net_arch=[400, 400]))
    # model = A2C("MlpPolicy", env, verbose=0, tensorboard_log=tensorboard_path, learning_rate=lr_actor, n_steps=200,
    #             gamma=gamma, policy_kwargs=dict(net_arch=dict(pi=[400, 400], vf=[400, 400])), normalize_advantage=True)

    checkpoint_callback = CheckpointVecNormCallback(save_freq=max(100000 // n_envs, 1), save_path=ckpt_save_path,
                                                    save_norm_data=True)
    update_batch_callback = UpdateBatchSizeCallback(threshold=1)
    eval_save_norm_callback = SaveVecNormalizeCallback(save_freq=1, save_path=best_model_save_path)
    eval_callback = EvalCallback(eval_env, best_model_save_path=best_model_save_path, n_eval_episodes=n_eval_envs,
                                 log_path=log_path, callback_on_new_best=eval_save_norm_callback,
                                 callback_after_eval=update_batch_callback, eval_freq=max(test_iter // n_envs, 1))

    # Create the callback list
    callback = CallbackList([checkpoint_callback, eval_callback])

    model.learn(max_steps, callback=callback, progress_bar=True, log_interval=1)
    # model.learn(max_steps, callback=eval_callback, progress_bar=True, log_interval=1)
    model.save(final_save_path)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="training RANDPOL Agent")

    parser.add_argument("-n", "--name", type=str,
                        help="model name, for saving and loading,"
                             " if not set, training will continue from a pretrained checkpoint", default="RANDPOL")

    parser.add_argument("-e", "--env", type=str,
                        help="environment", default="QuadrupedGymEnv-v0")
    # parser.add_argument("-e", "--env", type=str,
    #                     help="environment", default="Hopper-v4")
    # parser.add_argument("-e", "--env", type=str,
    #                     help="environment", default="LunarLander-v2")
    # parser.add_argument("-e", "--env", type=str,
    #                     help="environment", default="HalfCheetah-v4")
    # parser.add_argument("-e", "--env", type=str,
    #                     help="environment", default="Ant-v4")
    # parser.add_argument("-e", "--env", type=str,
    #                     help="environment", default="MountainCarContinuous-v0")
    # parser.add_argument("-e", "--env", type=str,
    #                     help="environment", default="InvertedPendulum-v4")
    # parser.add_argument("-d", "--decay_rate", type=int,
    #                     help="number of episodes for epsilon decaying, default: 500000", default=500000)
    parser.add_argument("-o", "--optimizer", type=str,
                        help="optimizing algorithm ('RMSprop', 'Adam'), default: 'Adam'", default='Adam')
    parser.add_argument("--lr_actor", type=float,
                        help="learning rate for the Actor optimizer, default: 0.0001", default=3e-4)
    parser.add_argument("--lr_critic", type=float,
                        help="learning rate for the Critic optimizer, default: 0.0001", default=3e-4)

    parser.add_argument("-g", "--gamma", type=float,
                        help="discount factor, default: 0.99", default=0.99)
    parser.add_argument("-s", "--buffer_size", type=int,
                        help="Replay Buffer size, default: 5000000", default=1_000_000)

    parser.add_argument("-b", "--batch_size", type=int,
                        help="number of samples in each batch, default: 64", default=128)
    parser.add_argument("-i", "--steps_to_start_learn", type=int,
                        help="number of random steps before the agents starts learning, default: 10000", default=100)
    parser.add_argument("-c", "--test_iter", type=int,
                        help="number of iterations between policy testing, default: 10000", default=10000)
    parser.add_argument("-m", "--max_steps", type=int,
                        help="number of iterations to run, default: 20000000", default=80000000)
    # parser.add_argument("-m", "--max_steps", type=int,
    #                     help="number of iterations to run, default: 20000000", default=1400000)
    parser.add_argument("-sd", "--seed", type=int,
                        help="seed, default: 12345", default=12345)
    parser.add_argument("-l", "--logs", help="parent folder containing everything", default="logs")
    parser.add_argument('--rand', dest='rand', action='store_true')
    parser.add_argument('--no-rand', dest='rand', action='store_false')
    parser.set_defaults(rand=True)

    main(parser)
