import os
import time
import csv

import numpy as np
import pandas as pd
import gymnasium as gym
from gymnasium import wrappers
from gym.wrappers.monitoring.video_recorder import VideoRecorder
import torch
from stable_baselines3.sac import SAC
from stable_baselines3.td3 import TD3
from stable_baselines3.ddpg import DDPG
from stable_baselines3.ppo import PPO
from stable_baselines3.a2c import A2C
from utils.sb3_randpol_algorithm import RANDPOL
from utils_on_policy.randpol_algorithm_2 import RANDPOL2
from stable_baselines3.common.vec_env import DummyVecEnv, VecNormalize, VecVideoRecorder

# from envs.running_task_cartesian import QuadrupedGymEnv
# from envs.ros.running_task_cartesian_ros import QuadrupedGymEnv

from envs.running_task_cartesian_go1 import QuadrupedGymEnv
# from envs.running_task_joint_go1 import QuadrupedGymEnv

# from envs.running_task_joint import QuadrupedGymEnv
# from envs.ros.running_task_joint_ros import QuadrupedGymEnv

# from usc_learning.envs.quadruped_master.quadruped_gym_env import QuadrupedGymEnv

if __name__ == "__main__":
    load_best_model = True
    record_video = False
    export_model = False
    save_data = False
    checkpoint = 175_00000
    model_root_dir = os.path.join("logs", "2024-05-17_23-09-07_QuadrupedGymEnv-v0")
    vid_dir = os.path.join(model_root_dir, "video")
    csv_dir = os.path.join(model_root_dir, "data")
    env = model_root_dir.split("_")[-1]
    if load_best_model:
        model_dir = os.path.join(model_root_dir, "best_model")
        best_model_path = os.path.join(model_dir, "best_model")
        vec_norm_path = os.path.join(model_dir, "vecnormalize.pkl")
    else:
        model_dir = os.path.join(model_root_dir, "saved_checkpoints", f"checkpoint_{checkpoint}_steps")
        best_model_path = os.path.join(model_dir, f"rl_model_{checkpoint}_steps")
        vec_norm_path = os.path.join(model_dir, "vecnormalize.pkl")

    csv_writer_full = None
    csv_writer_cur = None
    if save_data:
        os.makedirs(csv_dir, exist_ok=True)
        f_data_full = open(os.path.join(csv_dir, "data_full.csv"), 'w', newline='')
        f_data_cur = open(os.path.join(csv_dir, "data_cur.csv"), 'w', newline='')
        csv_writer_full = csv.writer(f_data_full)
        csv_writer_cur = csv.writer(f_data_cur)

    env_kwargs = {}

    if env == "QuadrupedGymEnv-v0":
        # End-to-end
        # env_kwargs = dict(render=True, time_step=0.001, action_repeat=10, obs_hist_len=5)  # Joint
        env_kwargs = dict(render=True, time_step=0.001,
                          action_repeat=10, obs_hist_len=10, obs_hist_space=5)  # Cartesian

        # env_kwargs = dict(render=True,
        #                   task_env="FWD_LOCOMOTION",
        #                   observation_space_mode="DEFAULT_CONTACTS",
        #                   energy_weight=0.008,
        #                   distance_weight=4.0,
        #                   time_remaining_in_obs_space=False,
        #                   gait_signal_in_obs_space=False,
        #                   add_terrain_noise=True,
        #                   observation_history_length=5,
        #                   randomize_dynamics=True,
        #                   observation_noise_stdev=0.05)

        if record_video:
            env = DummyVecEnv(
                [lambda: wrappers.RecordVideo(QuadrupedGymEnv(**env_kwargs), vid_dir)])
        else:
            env = DummyVecEnv([lambda: QuadrupedGymEnv(**env_kwargs)])
    else:
        if env == "LunarLander-v2":
            env_kwargs = dict(continuous=True)

        if record_video:
            env = DummyVecEnv(
                [lambda: wrappers.RecordVideo(gym.make(env, render_mode='rgb_array', **env_kwargs), vid_dir)])
        else:
            env = DummyVecEnv([lambda: gym.make(env, render_mode='human', **env_kwargs)])
    env = VecNormalize.load(vec_norm_path, env)

    # model = RANDPOL.load(best_model_path, env)
    model = RANDPOL2.load(best_model_path, env)
    # model = SAC.load(best_model_path, env)
    # model = TD3.load(best_model_path, env)
    # model = DDPG.load(best_model_path, env)
    # model = PPO.load(best_model_path, env)
    # model = A2C.load(best_model_path, env)

    model.policy.eval()
    device = model.device

    num_test = 5
    test_iter = 0

    obs = env.reset()
    reward_total = 0.0
    num_steps = 0
    obs_arr = []
    action_arr = []

    obs_len = env.observation_space.shape[-1]
    obs_len_single = int(obs_len / 5)

    while test_iter < num_test:
        action, _ = model.predict(obs, deterministic=True)
        # th_obs = torch.from_numpy(obs).to(device)
        # action = model.actor_target(th_obs)
        # action = action.cpu().detach().numpy()
        # print(action[0])
        _obs = np.copy(obs[0])
        obs_arr.append(_obs)
        action_arr.append(np.copy(action[0]))

        obs, reward, done, info = env.step(action)
        if save_data:
            _obs = np.copy(obs[0])
            _obs_single = _obs[:obs_len_single]
            _pos = info[0]["pos"]
            csv_writer_full.writerow(_obs)
            # csv_writer_cur.writerow(_obs[:obs_len_single])
            csv_writer_cur.writerow(np.concatenate([_obs_single, _pos]))

        reward = env.unnormalize_reward(reward)
        num_steps += 1
        reward_total += reward
        # time.sleep(0.1)
        if done:
            info = info[0]
            info.pop("terminal_observation")
            print("===============================")
            print(info)
            print(f"Running {num_steps} steps we got a total reward of {np.mean(reward_total)}")
            print("===============================")
            reward_total = 0.0
            num_steps = 0
            test_iter += 1
            # df = pd.DataFrame(np.array(obs_arr))
            # df.to_csv("/home/zhuochen/" + "obs_pyb_0" + ".csv", index=False)
            # df = pd.DataFrame(np.array(action_arr))
            # df.to_csv("/home/zhuochen/" + "action_pyb_0" + ".csv", index=False)
    env.close()

    if export_model:
        actor = model.policy.actor.cpu()
        model_scripted = torch.jit.trace(actor, torch.from_numpy(obs))
        model_save_dir = os.path.join(model_root_dir, "exported_model")
        os.makedirs(model_save_dir, exist_ok=True)
        model_save_path = os.path.join(model_save_dir, "model.pt")
        model_scripted.save(model_save_path)

        vecnorm_save_path = os.path.join(model_save_dir, "vecnorm_params.csv")
        # act_space_save_path = os.path.join(model_save_dir, "action_space.csv")
        vecnorm_arr = np.vstack((
            env.obs_rms.mean,
            env.obs_rms.var,
            env.observation_space.high,
            env.observation_space.low
        ))
        np.savetxt(vecnorm_save_path, vecnorm_arr, delimiter=',')
