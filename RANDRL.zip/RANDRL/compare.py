import os
import traceback
from tensorboard.backend.event_processing.event_accumulator import EventAccumulator
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from collections import defaultdict

COLORS = {
    "RANDPOL2": "cyan",
    "RANDPOL": "cyan",
    "RANDPOL1": "gold",
    "DDPG": "green",
    "PPO": "brown",
    "A2C": "blue",
    "TD3": "purple",
    "SAC": "red",
}


def get_interpolation(data, x_idx):
    x_fill = []
    y_fill = []
    _y_fill = []

    x_upper = 9999999999

    for i in range(len(data)):
        d = data[i]
        x = d[:, x_idx]
        x_upper = min(x_upper, x[-1])
        y = d[:, -1]
        # x_fill.extend(x)
        _y_fill.append((x, y))
    for i, (x, y) in enumerate(_y_fill):
        mask = x <= x_upper
        count = sum(mask)
        x_fill.extend(x[:count])
        _y_fill[i] = (x[:count], y[:count])

    x_fill = np.sort(x_fill)
    for x, y in _y_fill:
        yf = np.interp(x_fill, x, y)
        y_fill.append(yf)
    return x_fill, y_fill


def plot_data(alg_data_dict, env_name, scalar_type, mode="time"):
    if mode == "time":
        x_idx = 0
        x_label = "Wall time (s)"
    else:
        x_idx = 1
        x_label = "Timesteps"
    y_label = "Cumulative Reward"

    for alg_name in alg_data_dict:
        d = alg_data_dict[alg_name]
        if alg_name == "RANDPOL2":
            alg_name = "RANDPOL"
        x_fill, y_fill = get_interpolation(d, x_idx)
        plt.plot(x_fill, np.mean(y_fill, axis=0), label=alg_name, color=COLORS[alg_name])
        plt.fill_between(x_fill, np.min(y_fill, axis=0), np.max(y_fill, axis=0), interpolate=True,
                         color=COLORS[alg_name],
                         alpha=0.2)

    plt.xlabel(x_label)
    plt.ylabel(y_label)
    if env_name == "Quadruped_Joint_New":
        plt.title("Quadruped Robot")
    else:
        plt.title(env_name)
    plt.legend()
    # plt.savefig("benchmark/" + env_name + ".png", bbox_inches='tight')
    plt.savefig(f"{scalar_type}_{env_name}.png", bbox_inches='tight')
    plt.clf()


def tflog2pandas(path, scalar):
    runlog_data = pd.DataFrame({"Wall Time": [], "Step": [], "Value": []})
    try:
        event_acc = EventAccumulator(path)
        event_acc.Reload()
        event_list = event_acc.Scalars(scalar)
        value = list(map(lambda x: x.value, event_list))
        step = list(map(lambda x: x.step, event_list))
        wall_time = list(map(lambda x: x.wall_time, event_list))
        r = {"Wall Time": wall_time, "Step": step, "Value": value}
        r = pd.DataFrame(r)
        runlog_data = pd.concat([runlog_data, r])
    # Dirty catch of DataLossError
    except Exception:
        print("Event file possibly corrupt: {}".format(path))
        traceback.print_exc()
    runlog_data = runlog_data.to_numpy()
    runlog_data[:, 0] -= runlog_data[0][0]
    return runlog_data


if __name__ == "__main__":
    env_root_dir = "benchmark"
    # envs = os.listdir(env_root_dir)
    # envs = ["Quadruped_Joint_New"]
    envs = ["Ant"]
    # envs = ["InvertedPendulum", "LunarLander", "MountainCarContinuous", "Quadruped_Joint_New"]
    # algorithms = ["RANDPOL1", "RANDPOL2", "PPO", "TD3", "SAC", ]
    for env in envs:
        print(f"Reading data from {env}...")
        alg_data_dict = defaultdict(list)
        env_dir = os.path.join(env_root_dir, env)
        models = os.listdir(env_dir)
        for scalar in ["rollout/ep_rew_mean", "eval/mean_reward"]:
            for model in models:
                log_dir = os.path.join(env_dir, model, "tensorboard_log")
                log_subdir = os.listdir(log_dir)[0]
                alg_name = log_subdir.split("_")[0]
                # if alg_name not in algorithms:
                #     continue
                # if alg_name == "TD3":
                #     continue
                log_filename = os.listdir(os.path.join(log_dir, log_subdir))[0]
                log_path = os.path.join(log_dir, log_subdir, log_filename)
                df = tflog2pandas(log_path, scalar)
                alg_data_dict[alg_name].append(df)
            plot_data(alg_data_dict, env, scalar.split("/")[0], mode="time")
            alg_data_dict.clear()
        print(f"Finished plotting {env}!")
