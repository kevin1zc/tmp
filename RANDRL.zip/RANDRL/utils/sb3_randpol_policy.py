from typing import Any, Dict, List, Optional, Tuple, Type, Union

import gymnasium as gym
import numpy as np
import torch as th
from torch import nn

from stable_baselines3.common.policies import BasePolicy, BaseModel
from stable_baselines3.common.preprocessing import get_action_dim, get_flattened_obs_dim, preprocess_obs
from stable_baselines3.common.torch_layers import get_actor_critic_arch
from stable_baselines3.common.type_aliases import Schedule


def create_frozen_mlp(
        input_dim: int,
        net_arch: List[int],
        activation_fn: Type[nn.Module] = nn.ReLU,
        in_action_idx: Optional[int] = None,
        action_dim: Optional[int] = None
) -> List[nn.Module]:
    """
    Create a multi layer perceptron (MLP), which is
    a collection of fully-connected layers each followed by an activation function.

    :param input_dim: Dimension of the input vector
    :param net_arch: Architecture of the neural net
        It represents the number of units per layer.
        The length of this list is the number of layers.
    :param activation_fn: The activation function
        to use after each layer.
    :param in_action_idx: Index of the layer after which the action input of critic is appended.
    :param action_dim: Size of action input.
    :return:
    """

    if len(net_arch) > 0:
        layer_1 = nn.Linear(input_dim, net_arch[0])
        layer_1.weight.requires_grad = False
        layer_1.weight.data.normal_(0, 0.1)
        layer_1.bias.requires_grad = False
        layer_1.bias.data.normal_(0, 0.1)
        modules = [layer_1, activation_fn()]
    else:
        modules = []

    for idx in range(len(net_arch) - 1):
        if in_action_idx is not None:
            layer = nn.Linear(net_arch[idx] + action_dim, net_arch[idx + 1])
        else:
            layer = nn.Linear(net_arch[idx], net_arch[idx + 1])
        layer.weight.requires_grad = False
        # layer.weight.data_pyb.normal_(0, 0.1)
        layer.bias.requires_grad = False
        # layer.bias.data_pyb.normal_(0, 0.1)
        modules.append(layer)
        modules.append(activation_fn())
    return modules


def create_trainable_mlp(
        input_dim: int,
        net_arch: List[int],
        activation_fn: Type[nn.Module] = nn.ReLU,
        in_action_idx: Optional[int] = None,
        action_dim: Optional[int] = None
) -> List[nn.Module]:
    """
    Create a multi layer perceptron (MLP), which is
    a collection of fully-connected layers each followed by an activation function.

    :param input_dim: Dimension of the input vector
    :param net_arch: Architecture of the neural net
        It represents the number of units per layer.
        The length of this list is the number of layers.
    :param activation_fn: The activation function
        to use after each layer.
    :param in_action_idx: Index of the layer after which the action input of critic is appended.
    :param action_dim: Size of action input.
    :return:
    """

    if len(net_arch) > 0:
        layer_1 = nn.Linear(input_dim, net_arch[0])
        modules = [layer_1, activation_fn()]
    else:
        modules = []

    for idx in range(len(net_arch) - 1):
        if in_action_idx is not None:
            layer = nn.Linear(net_arch[idx] + action_dim, net_arch[idx + 1])
        else:
            layer = nn.Linear(net_arch[idx], net_arch[idx + 1])
        modules.append(layer)
        modules.append(activation_fn())
    return modules


class Actor(BasePolicy):
    """
    Actor network (policy) for RANDPOL.

    :param observation_space: Obervation space
    :param action_space: Action space
    :param net_arch: Network architecture
    :param activation_fn: Activation function
    """

    def __init__(
            self,
            observation_space: gym.spaces.Space,
            action_space: gym.spaces.Space,
            net_arch: List[int],
            activation_fn: Type[nn.Module] = nn.ReLU,
    ):
        super().__init__(
            observation_space,
            action_space,
            squash_output=True,
        )

        self.net_arch = net_arch
        self.obs_dim = get_flattened_obs_dim(observation_space)
        self.activation_fn = activation_fn

        action_dim = get_action_dim(self.action_space)
        modules_random = create_frozen_mlp(self.obs_dim, net_arch, activation_fn)
        self.net_random = nn.Sequential(*modules_random)

        # Deterministic action
        last_layer_dim = net_arch[-1] if len(net_arch) > 0 else self.obs_dim
        modules_final = [nn.Linear(last_layer_dim, action_dim), nn.Tanh()]
        # modules_final[0].weight.data_pyb.normal_(0, 0.01)
        # modules_final[0].bias.data_pyb.normal_(0, 0.01)
        self.net_trainable = nn.Sequential(*modules_final)

    def _get_constructor_parameters(self) -> Dict[str, Any]:
        data = super()._get_constructor_parameters()
        data.update(
            dict(
                net_arch=self.net_arch,
                features_dim=self.obs_dim,
                activation_fn=self.activation_fn,
            )
        )
        return data

    def forward(self, obs: th.Tensor) -> th.Tensor:
        # assert deterministic, 'The TD3 actor only outputs deterministic actions'
        preprocessed_obs = preprocess_obs(obs, self.observation_space, normalize_images=False)
        features = self.net_random(preprocessed_obs)
        return self.net_trainable(features)

    def _predict(self, observation: th.Tensor, deterministic: bool = False) -> th.Tensor:
        # Note: the deterministic parameter is ignored in the case of TD3.
        #   Predictions are always deterministic.
        return self(observation)


class Critic(BaseModel):
    """
    Critic network(s) for DDPG/SAC/TD3.
    It represents the action-state value function (Q-value function).
    Compared to A2C/PPO critics, this one represents the Q-value
    and takes the continuous action as input. It is concatenated with the state
    and then fed to the network which outputs a single value: Q(s, a).
    For more recent algorithms like SAC/TD3, multiple networks
    are created to give different estimates.

    By default, it creates two critic networks used to reduce overestimation
    thanks to clipped Q-learning (cf TD3 paper).

    :param observation_space: Obervation space
    :param action_space: Action space
    :param net_arch: Network architecture
    :param activation_fn: Activation function
    """

    def __init__(
            self,
            observation_space: gym.spaces.Space,
            action_space: gym.spaces.Space,
            net_arch: List[int],
            activation_fn: Type[nn.Module] = nn.ReLU,
            n_critics: int = 1,
    ):
        super().__init__(
            observation_space,
            action_space,
        )

        action_dim = get_action_dim(self.action_space)
        obs_dim = get_flattened_obs_dim(observation_space)

        self.in_action_idx = 0

        self.critics = []

        for idx in range(n_critics):
            modules_random = create_frozen_mlp(obs_dim + action_dim, net_arch, activation_fn)
            # modules_random = create_trainable_mlp(obs_dim + action_dim, net_arch, activation_fn)
            net_random = nn.Sequential(*modules_random)

            # Deterministic action
            # modules_random = create_frozen_mlp(obs_dim, net_arch, activation_fn,
            #                                    in_action_idx=self.in_action_idx, action_dim=action_dim)
            # modules_random = create_trainable_mlp(obs_dim, net_arch, activation_fn,
            #                                       in_action_idx=self.in_action_idx, action_dim=action_dim)

            last_layer_dim = net_arch[-1] if len(net_arch) > 0 else obs_dim + action_dim
            net_trainable = nn.Linear(last_layer_dim, 1)
            # net_trainable.weight.data_pyb.normal_(0, 0.01)
            # net_trainable.bias.data_pyb.normal_(0, 0.01)

            self.critics.append((net_random, net_trainable))
            self.add_module(f"qf_random_{idx}", net_random)

            # self.critics.append((modules_random, net_trainable))
            # for layer, module in enumerate(modules_random):
            #     self.add_module(f"qf_random_{idx}_layer_{layer}", module)

            self.add_module(f"qf_trainable_{idx}", net_trainable)

    def forward(self, obs: th.Tensor, actions: th.Tensor) -> Tuple[th.Tensor, ...]:
        # Learn the features extractor using the policy loss only
        # when the features_extractor is shared with the actor

        preprocessed_obs = preprocess_obs(obs, self.observation_space, normalize_images=False)
        inputs = th.cat([preprocessed_obs, actions], dim=1)
        outputs = []
        for net_random, net_trainable in self.critics:
            features = net_random(inputs)
            output = net_trainable(features)
            outputs.append(output)
        return tuple(outputs)

        # preprocessed_obs = preprocess_obs(obs, self.observation_space, normalize_images=False)
        # outputs = []
        # for modules_random, net_trainable in self.critics:
        #     features = preprocessed_obs
        #     for i, module in enumerate(modules_random):
        #         if i - 1 == self.in_action_idx:
        #             features = th.cat([features, actions], dim=1)
        #         features = module(features)
        #     output = net_trainable(features)
        #     outputs.append(output)
        # return tuple(outputs)

    def q1_forward(self, obs: th.Tensor, actions: th.Tensor) -> th.Tensor:
        """
        Only predict the Q-value using the first network.
        This allows to reduce computation when all the estimates are not needed
        (e.g. when updating the policy in TD3).
        """
        preprocessed_obs = preprocess_obs(obs, self.observation_space, normalize_images=False)
        inputs = th.cat([preprocessed_obs, actions], dim=1)
        net_random, net_trainable = self.critics[0]
        features = net_random(inputs)
        output = net_trainable(features)
        return output

        # preprocessed_obs = preprocess_obs(obs, self.observation_space, normalize_images=False)
        # modules_random, net_trainable = self.critics[0]
        # features = preprocessed_obs
        # for i, module in enumerate(modules_random):
        #     if i - 1 == self.in_action_idx:
        #         features = th.cat([features, actions], dim=1)
        #     features = module(features)
        # output = net_trainable(features)
        # return output


class RANDPOLPolicy(BasePolicy):

    def __init__(
            self,
            observation_space: gym.spaces.Space,
            action_space: gym.spaces.Space,
            lr_schedule: Schedule,
            lr_actor: int = 1e-4,
            lr_critic: int = 1e-4,
            net_arch: Optional[Union[List[int], Dict[str, List[int]]]] = None,
            activation_fn: Type[nn.Module] = nn.ReLU,
            optimizer_class: Type[th.optim.Optimizer] = th.optim.Adam,
            optimizer_kwargs: Optional[Dict[str, Any]] = None,
            squash_output: bool = True,
            n_critics: int = 1
    ):
        super().__init__(
            observation_space,
            action_space,
            optimizer_class=optimizer_class,
            optimizer_kwargs=optimizer_kwargs,
            squash_output=squash_output,
        )
        if net_arch is None:
            net_arch = [256, 256]

        actor_arch, critic_arch = get_actor_critic_arch(net_arch)

        self.net_arch = net_arch
        self.activation_fn = activation_fn
        self.net_args = {
            "observation_space": self.observation_space,
            "action_space": self.action_space,
            "net_arch": actor_arch,
            "activation_fn": self.activation_fn,
        }
        self.actor_kwargs = self.net_args.copy()

        self.critic_kwargs = self.net_args.copy()
        self.critic_kwargs.update(
            {
                "net_arch": critic_arch,
                "n_critics": n_critics
            }
        )
        self.lr_actor = lr_actor
        self.lr_critic = lr_critic

        self.actor, self.actor_target = None, None
        self.critic, self.critic_target = None, None

        self._build(lr_schedule)

    def _build(self, lr_schedule: Schedule) -> None:
        # Create actor and target
        # the features extractor should not be shared
        self.actor = self.make_actor()
        self.actor_target = self.make_actor()
        # Initialize the target to have the same weights as the actor
        self.actor_target.load_state_dict(self.actor.state_dict())
        self.actor.optimizer = self.optimizer_class(filter(lambda p: p.requires_grad, self.actor.parameters()),
                                                    lr=self.lr_actor, **self.optimizer_kwargs)

        self.critic = self.make_critic()
        self.critic_target = self.make_critic()

        self.critic_target.load_state_dict(self.critic.state_dict())
        self.critic.optimizer = self.optimizer_class(filter(lambda p: p.requires_grad, self.critic.parameters()),
                                                     lr=self.lr_critic, **self.optimizer_kwargs)

        # Target networks should always be in eval mode
        self.actor_target.set_training_mode(False)
        self.critic_target.set_training_mode(False)

    def make_actor(self) -> Actor:
        return Actor(**self.actor_kwargs).to(self.device)

    def make_critic(self) -> Critic:
        return Critic(**self.critic_kwargs).to(self.device)

    def _predict(self, observation: th.Tensor, deterministic: bool = False) -> th.Tensor:
        # Note: the deterministic parameter is ignored in the case of TD3.
        #   Predictions are always deterministic.
        return self.actor(observation)

    def forward(self, observation: th.Tensor, deterministic: bool = False) -> th.Tensor:
        return self._predict(observation, deterministic=deterministic)

    def _get_constructor_parameters(self) -> Dict[str, Any]:
        data = super()._get_constructor_parameters()

        data.update(
            dict(
                net_arch=self.net_arch,
                activation_fn=self.net_args["activation_fn"],
                optimizer_class=self.optimizer_class,
                optimizer_kwargs=self.optimizer_kwargs,
            )
        )
        return data

    def set_training_mode(self, mode: bool) -> None:
        """
        Put the policy in either training or evaluation mode.

        This affects certain modules, such as batch normalisation and dropout.

        :param mode: if true, set to training mode, else set to evaluation mode
        """
        self.actor.set_training_mode(mode)
        self.critic.set_training_mode(mode)
        self.training = mode
