import os
from typing import Optional

from utils.sb3_randpol_algorithm import RANDPOL
from stable_baselines3.common.callbacks import BaseCallback, CheckpointCallback


class SaveVecNormalizeCallback(BaseCallback):
    """
    Callback for saving a VecNormalize wrapper every ``save_freq`` steps
    :param save_freq: (int)
    :param save_path: (str) Path to the folder where ``VecNormalize`` will be saved, as ``vecnormalize.pkl``
    :param name_prefix: (str) Common prefix to the saved ``VecNormalize``, if None (default)
        only one file will be kept.
    """

    def __init__(self, save_freq: int, save_path: str, name_prefix: Optional[str] = None, verbose: int = 0):
        super(SaveVecNormalizeCallback, self).__init__(verbose)
        self.save_freq = save_freq
        self.save_path = save_path
        self.name_prefix = name_prefix

    def _init_callback(self) -> None:
        # Create folder if needed
        if self.save_path is not None:
            os.makedirs(self.save_path, exist_ok=True)

    def _on_step(self) -> bool:
        if self.n_calls % self.save_freq == 0:
            if self.name_prefix is not None:
                path = os.path.join(self.save_path, f"{self.name_prefix}_{self.num_timesteps}_steps.pkl")
            else:
                path = os.path.join(self.save_path, "vecnormalize.pkl")
            if self.model.get_vec_normalize_env() is not None:
                self.model.get_vec_normalize_env().save(path)
                if self.verbose > 1:
                    print(f"Saving VecNormalize to {path}")
        return True

    def update_save_path(self, new_path: str):
        self.save_path = new_path
        if self.save_path is not None:
            os.makedirs(self.save_path, exist_ok=True)


class CheckpointVecNormCallback(CheckpointCallback):
    """
    Callback for saving a model every ``save_freq`` calls
    to ``env.step()``.

    .. warning::

      When using multiple environments, each call to  ``env.step()``
      will effectively correspond to ``n_envs`` steps.
      To account for that, you can use ``save_freq = max(save_freq // n_envs, 1)``

    :param save_freq:
    :param save_path: Path to the folder where the model will be saved.
    :param name_prefix: Common prefix to the saved models
    :param verbose:
    """

    def __init__(self, save_freq: int, save_path: str, name_prefix: str = "rl_model", verbose: int = 0,
                 save_norm_data: bool = True):
        super().__init__(save_freq, save_path, name_prefix, verbose=verbose)
        self.save_norm_callback = None
        if save_norm_data:
            self.save_norm_callback = SaveVecNormalizeCallback(save_freq=1, save_path=save_path)
            self.save_norm_callback.parent = self
        self.save_norm_data = save_norm_data

    def _init_callback(self) -> None:
        super(CheckpointVecNormCallback, self)._init_callback()
        if self.save_norm_callback is not None:
            self.save_norm_callback.init_callback(self.model)

    def _on_step(self) -> bool:
        if not self.save_norm_data:
            return super()._on_step()

        if self.n_calls % self.save_freq == 0:
            path = os.path.join(self.save_path, f"checkpoint_{self.num_timesteps}_steps")
            os.makedirs(path, exist_ok=True)
            self.save_norm_callback.update_save_path(path)
            self.save_norm_callback.on_step()

            path = os.path.join(path, f"{self.name_prefix}_{self.num_timesteps}_steps")
            self.model.save(path)
            if self.verbose > 1:
                print(f"Saving model checkpoint to {path}")
        return True


class UpdateBatchSizeCallback(BaseCallback):

    def __init__(self, threshold: int, verbose: int = 0):
        super(UpdateBatchSizeCallback, self).__init__(verbose)
        self.last_reward = None
        self.threshold = threshold

    def _on_step(self) -> bool:
        if isinstance(self.model, RANDPOL):
            cur_reward = self.parent.last_mean_reward
            if self.last_reward is None:
                self.last_reward = cur_reward
            else:
                diff = cur_reward - self.last_reward
                if -5 < diff < 2:
                    self.model.increase_batch_size()
                # elif diff > 0:
                #     self.model.decrease_batch_size()
                self.last_reward = cur_reward

            self.logger.record("train/batch_size", self.model.batch_size)
        return True
