import matplotlib.pyplot as plt
import pandas as pd
import os

model_root_dir = os.path.join("logs", "randpol2_cartesian_new_init_bodyH_2023-03-29_00-58-56_QuadrupedGymEnv-v0")

pyb_data_dir = os.path.join(model_root_dir, "data_pyb", "data_cur.csv")
ros_data_dir = os.path.join(model_root_dir, "data_ros", "data_cur.csv")
exp_data_dir = "/home/zhuochen/hw_data/randpol2_cartesian_new_init_bodyH_2023-03-29_00-58-56_QuadrupedGymEnv-v0/data/data_cur.csv"

data_pyb = pd.read_csv(pyb_data_dir).to_numpy()
data_ros = pd.read_csv(ros_data_dir).to_numpy()
data_exp = pd.read_csv(exp_data_dir).to_numpy()

plt.xlabel("Steps")
plt.ylabel("Height (m)")
plt.plot(data_pyb[:400, -1], label="PyBullet")
plt.plot(data_ros[:400, -1], label="ROS")
plt.plot(data_exp[:400, -1], label="Hardware")
plt.legend()

# plt.show()
plt.savefig(os.path.join(model_root_dir, "height.png"))
