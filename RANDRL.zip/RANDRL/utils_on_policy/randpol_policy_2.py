from stable_baselines3.common.policies import ActorCriticPolicy
from stable_baselines3.common.torch_layers import BaseFeaturesExtractor, MlpExtractor
from torch import nn
from typing import Any, Dict, List, Optional, Tuple, Type, TypeVar, Union
import torch as th
from stable_baselines3.common.utils import get_device, is_vectorized_observation, obs_as_tensor


class RANDPOLMlpExtractor(MlpExtractor):
    def __init__(self, feature_dim: int, net_arch: Union[List[int], Dict[str, List[int]]],
                 activation_fn: Type[nn.Module], device: Union[th.device, str] = "auto") -> None:
        super().__init__(feature_dim, net_arch, activation_fn, device)
        device = get_device(device)
        policy_net: List[nn.Module] = []
        value_net: List[nn.Module] = []
        last_layer_dim_pi = feature_dim
        last_layer_dim_vf = feature_dim

        # save dimensions of layers in policy and value nets
        if isinstance(net_arch, dict):
            # Note: if key is not specificed, assume linear network
            pi_layers_dims = net_arch.get("pi", [])  # Layer sizes of the policy network
            vf_layers_dims = net_arch.get("vf", [])  # Layer sizes of the value network
        else:
            pi_layers_dims = vf_layers_dims = net_arch
        # Iterate through the policy layers and build the policy net
        for curr_layer_dim in pi_layers_dims:
            layer = nn.Linear(last_layer_dim_pi, curr_layer_dim)
            layer.weight.requires_grad = False
            layer.bias.requires_grad = False
            policy_net.append(layer)
            policy_net.append(activation_fn())
            last_layer_dim_pi = curr_layer_dim
        # Iterate through the value layers and build the value net
        for curr_layer_dim in vf_layers_dims:
            layer = nn.Linear(last_layer_dim_vf, curr_layer_dim)
            layer.weight.requires_grad = False
            layer.bias.requires_grad = False
            value_net.append(layer)
            value_net.append(activation_fn())
            last_layer_dim_vf = curr_layer_dim

        # Save dim, used to create the distributions
        self.latent_dim_pi = last_layer_dim_pi
        self.latent_dim_vf = last_layer_dim_vf

        # Create networks
        # If the list of layers is empty, the network will just act as an Identity module
        self.policy_net = nn.Sequential(*policy_net).to(device)
        self.value_net = nn.Sequential(*value_net).to(device)


class RANDPOLPolicy(ActorCriticPolicy):

    def _build_mlp_extractor(self) -> None:
        """
        Create the policy and value networks.
        Part of the layers can be shared.
        """
        # Note: If net_arch is None and some features extractor is used,
        #       net_arch here is an empty list and mlp_extractor does not
        #       really contain any layers (acts like an identity module).
        self.mlp_extractor = RANDPOLMlpExtractor(
            self.features_dim,
            net_arch=self.net_arch,
            activation_fn=self.activation_fn,
            device=self.device,
        )
