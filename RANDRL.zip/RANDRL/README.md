#### This repository containes the code for the experiments for RANDPOL algorithm.

## Dependencies
|Library         | Version |
|----------------------|----|
|`Python`|  `3.6.9 `|
|`torch`|  `1.2.0`|
|`pybullet`| `2.6.2`|
|`gym`|  `0.14.0`|
|`tensorboard`|  `1.14.0`|

To train the agent use main.py and to enjoy the trained model used enjoy.py with path to trained model and record it to video folder.

